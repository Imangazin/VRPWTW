/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vrpwtw;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author ni15dz
 * this class sets all parameters entered by user and from Solomon DataSets
 */
public class Parameters {
    static int numberOfPopulation;
    static int numberOfGenerations;
    static int numberOfRuns;
    static int elite;
    static ArrayList<Locations> locations = new ArrayList<>();
    static String evaluationType;
    static int crossoverType;
    static double crossoverRate;
    static double mutationRate;
    static double fitnessValue;
    static int [] locationId;
    static int capacity;
    
    public int getNumberOfPopulation(){return numberOfPopulation;}
    public int getNumeberOfGenerations(){return numberOfGenerations;}
    public int getNumberOfRuns(){return numberOfRuns;}
    public static int getElite(){return elite;}
    public static ArrayList<Locations> getLocations(){return locations;}
    public String getEvolution(){return evaluationType;}
    public int getCrossoverType(){return crossoverType;}
    public static double getCrossoverRate(){return crossoverRate;}
    public static double getMutationRate(){return mutationRate;}
    public double getFitnessValue(){return fitnessValue;}
    public static int getCapacity(){return capacity;}
    public static void setLocationId(){
        for(int i=0; i<locations.size()-1;i++){
        locationId[i]=locations.get(i+1).customerNumber;       
        }
    }
    public static int [] getLocationId(){
       return locationId;
    }
    
    public static void setParameters (File fileName){
        BufferedReader readerParameters;
        BufferedReader readerSolomonData;
        try{
           readerParameters = new BufferedReader(new FileReader("src/vrpwtw/parameters.txt"));
                      
           String line=readerParameters.readLine();
           for(;;){
               if(line==null) break;
               String [] str = line.split(":");
               if(str[0].equalsIgnoreCase("Number of runs")) numberOfRuns = Integer.parseInt(str[1].trim()); 
               if(str[0].equalsIgnoreCase("Number of Generations")) numberOfGenerations = Integer.parseInt(str[1].trim());
               if(str[0].equalsIgnoreCase("Number of Population")) numberOfPopulation = Integer.parseInt(str[1].trim());
               if(str[0].equalsIgnoreCase("Elite")) elite = Integer.parseInt(str[1].trim());
               if(str[0].equalsIgnoreCase("Crossover Probability")) crossoverRate = Double.parseDouble(str[1].trim());
               if(str[0].equalsIgnoreCase("Mutation Probability")) mutationRate = Double.parseDouble(str[1].trim());
               if(str[0].equalsIgnoreCase("Crossover Type")) crossoverType = Integer.parseInt(str[1].trim());
               if(str[0].equalsIgnoreCase("Evaluation Type")) evaluationType = str[1].trim();
               line=readerParameters.readLine();
           }
           readerParameters.close();
//******************************************************************************************************************************          
           readerSolomonData = new BufferedReader (new FileReader("src/SolomonData/"+fileName.getName()));
            // readerSolomonData = new BufferedReader (new FileReader(fileName));
            
           int start=0,end=0;
           for(int i=0; i<fileName.getName().length();i++){
               if(fileName.getName().charAt(i)=='_') start=i;
               if(fileName.getName().charAt(i)=='.') end=i;
           }
           capacity = Integer.parseInt(fileName.getName().substring(start+1, end));          
           line = readerSolomonData.readLine();           
           ArrayList<Locations> l = new ArrayList<>();
           for(int i=0; i<10; i++){
               if(line==null) break; 
               String [] str = line.split(",");
               l.add(new Locations((int)Double.parseDouble(str[0]),(int)Double.parseDouble(str[1]),(int)Double.parseDouble(str[2]),
                       (int)Double.parseDouble(str[3]),(int)Double.parseDouble(str[4]),(int)Double.parseDouble(str[5]),(int)Double.parseDouble(str[6])));
               line = readerSolomonData.readLine();
           }
           locations.add(new Locations(0,0,0,0,0,0,0));
           for(int i=0; i<l.size(); i++){
               locations.add(i+1, l.get(i));
           }
            locationId = new int [l.size()]; 
           setLocationId();
                     
           readerSolomonData.close();
    
        }catch(IOException e){
        }
     
        
        
        
        
    }
}
