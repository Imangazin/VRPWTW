/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vrpwtw;

import java.util.ArrayList;


/**
 *
 * @author ni15dz
 */
public class Vehicle {
    ArrayList<Integer> path;
    int totalCapacity = Parameters.capacity;
    double totalDistanceTraveled = 0;
    int currentCapacity=0;
    ArrayList<Locations> locations = Parameters.getLocations();
    double currentTime = 0;
    public Vehicle(){
        path = new ArrayList<>();
        path.add(0);//assigning depot for vehicle as a starting point
        
    }
    //distance between two locations
    public double distance (Locations location_1, Locations location_2){
        return Math.sqrt(Math.pow(location_2.xCoordinate-location_1.xCoordinate, 2)
        + Math.pow(location_2.yCoordinate-location_1.yCoordinate, 2));     
    }
    //check if vehcile can serve the location
    public boolean isVehicleCanServeNewLocation (Locations newLocation){
        Locations lastLocation = locations.get(path.get(path.size()-1));
        if ((currentCapacity+newLocation.demand)<=totalCapacity && 
                ((distance(lastLocation,newLocation)+currentTime)<=newLocation.dueTime)){                       
             return true; 
            }else {
              return false;
          }                    
    }
    //adding new location to vehicle
    public void addNewLocation(Locations newLocation ){
        Locations lastLocation = locations.get(path.get(path.size()-1));
        path.add(newLocation.customerNumber);
        currentCapacity = currentCapacity+newLocation.demand;
        currentTime = currentTime+distance(lastLocation,newLocation)+newLocation.serviceTime;       
    }
    //total distance traveled by all vehicles
    public double getTotalDistanceTraveled(){
        for (int i=0; i<path.size()-1; i++)
            totalDistanceTraveled = totalDistanceTraveled + distance(locations.get(path.get(i)),locations.get(path.get(i+1)));
        
        totalDistanceTraveled=totalDistanceTraveled+distance(locations.get(path.size()-1),locations.get(0));
        return totalDistanceTraveled;
    }    
}
