/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vrpwtw;

/**
 *
 * @author ni15dz
 */
public class Locations {
    int customerNumber;
    int xCoordinate;
    int yCoordinate;
    int demand;
    int readyTime;
    int dueTime;
    int serviceTime;
    boolean flag=true;
    
    public Locations (int id, int  xCoord, int  yCoord, int demand, 
            int readyTime, int dueTime, int serviceTime){
        this.customerNumber = id;
        this.xCoordinate = xCoord;
        this.yCoordinate = yCoord;
        this.demand = demand;
        this.readyTime = readyTime;
        this.dueTime = dueTime;
        this.serviceTime = serviceTime;
    }
    public int getCustomerNumber (){return customerNumber;}
    public int getXCoordinate (){return xCoordinate;}
    public int getYCoordinate (){return yCoordinate;}
    public int getDemand (){return demand;}
    public int getReadyTime (){return readyTime;}
    public int getDueTime (){return dueTime;}
    public int getServiceTime (){return serviceTime;}
}
