/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vrpwtw;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author ni15dz
 */
public class Population {
    int populationSize = Parameters.numberOfPopulation;
    ArrayList<Chromosome> initialPopulation = new ArrayList<>(); 
    ArrayList<Chromosome> nextPopulation = new ArrayList<>();
    
    double averageFitness=0;
    //initial population
    public Population(){
        
        for (int i=0; i<populationSize; i++){
            nextPopulation.add(new Chromosome());
        }
        sortByFitness(nextPopulation);
        setAverageFitness();
    }
    //next generaion populations
    public Population(ArrayList<Chromosome> oldPopulation){
        
        int count = 0;
        ArrayList<Integer> parent1,parent2;
        Chromosome child1,child2;
        
        
        while (count<Parameters.numberOfPopulation){
         
            for(int i=0; i<Parameters.getElite();i++){
                nextPopulation.add(oldPopulation.get(i));
                count++;
            }
            
            parent1 = selectTournamentSelection(oldPopulation);           
            parent2 = selectTournamentSelection(oldPopulation);
            
            Random r = new Random();
            int crossoverRate = r.nextInt(100)+1;
            int mutationRate = r.nextInt(100)+1;
            
            if(crossoverRate<Parameters.getCrossoverRate()*100){
               
                
                child1=GeneticAlgorithm.crossover(parent1, parent2)[0];
                child2=GeneticAlgorithm.crossover(parent1, parent2)[1];
                
                if(mutationRate<Parameters.getMutationRate()*100){
                    child1=GeneticAlgorithm.inverseMutation(child1.chromosome);
                    child2=GeneticAlgorithm.inverseMutation(child2.chromosome);
                    nextPopulation.add(child1);count++;
                    nextPopulation.add(child2);count++;
                }else{
                    nextPopulation.add(child1);count++;
                    nextPopulation.add(child2);count++;
                }
                
            }else {
                Chromosome p1 = new Chromosome(parent1);
                Chromosome p2 = new Chromosome(parent2);
                nextPopulation.add(p1);count++;
                nextPopulation.add(p2);count++;
            }
        }
        
        
        
      sortByFitness(nextPopulation);
      setAverageFitness();
    }
    
    //sorts chromosomes by fitness
    public void sortByFitness(ArrayList<Chromosome> population){
        population.sort((chromosome1,chromosome2)->{
        int flag =0;
        if(chromosome1.getWeightedSumFitnessFitness() < chromosome2.getWeightedSumFitnessFitness()) flag = -1;
        else if (chromosome1.getWeightedSumFitnessFitness() > chromosome2.getWeightedSumFitnessFitness()) flag = 1;
        return flag;
        });
    }
    //tournament selection method k=2
    public ArrayList<Integer> selectTournamentSelection(ArrayList<Chromosome> population){
        ArrayList<Integer> chromosome = new ArrayList<>();
        Random random = new Random();
        int number1 = random.nextInt(Parameters.locationId.length-1);
        int number2 = random.nextInt(Parameters.locationId.length-1);
                
        if(population.get(number1).fitness<population.get(number2).fitness){
            chromosome = population.get(number1).chromosome;
        }else{
        chromosome = population.get(number2).chromosome;
        } 
        return chromosome;
    }
    public void setAverageFitness(){ //calculates average fitness for population
        for(int i=0; i<nextPopulation.size();i++){
            averageFitness = averageFitness+nextPopulation.get(i).fitness;
        }
        averageFitness=averageFitness/nextPopulation.size();
    }
}
