/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vrpwtw;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.stream.IntStream;

/**
 *
 * @author ni15dz
 * this class handles all GA operators
 */

public class GeneticAlgorithm {
    
    //crossover method, chooses which crossover method to use setted by user
    public static Chromosome [] crossover (ArrayList<Integer> parentChromosome1, ArrayList<Integer> parentChromosome2){
        Chromosome [] childChromosomes = new Chromosome [2];
        
        if(Parameters.crossoverType==1){
            childChromosomes = uniformOrderCrossover(parentChromosome1,parentChromosome2);
        } 
        if (Parameters.crossoverType==2){
            childChromosomes = partiallyMappedCrossover(parentChromosome1,parentChromosome2);
        }
        
        return childChromosomes;
    }
    //UOX crossover method
    public static Chromosome [] uniformOrderCrossover(ArrayList<Integer> parentChromosome1, ArrayList<Integer> parentChromosome2){
        
        Chromosome [] childChromosomes = new Chromosome [2];
        
        int [] mask = new int [parentChromosome1.size()];
        int[] childChromosome1 = new int [parentChromosome1.size()];
        int[] childChromosome2 = new int [parentChromosome2.size()];
        
        for(int i=0; i<parentChromosome1.size(); i++){
            double random = Math.random();
            mask[i]=(int)Math.round(random);
        }
        
        for(int i=0; i<mask.length; i++){
            if(mask[i]==1) {
                childChromosome1[i] = parentChromosome1.get(i);
                childChromosome2[i] = parentChromosome2.get(i);
            }           
        }
        ArrayList<Integer> temp1 = new ArrayList<>();
        for(int i=0; i<mask.length; i++){
           if(mask[i]==0){
               for(int j=0; j<mask.length; j++){
                if (contains(childChromosome1,parentChromosome2.get(j))==false){
                    temp1.add(parentChromosome2.get(j));
                }
               }
           } 
        }
        int count=0;
        for(int i=0; i<mask.length; i++){
           if(mask[i]==0){
               childChromosome1[i]=temp1.get(count);
               count++;
           } 
        }
        
        ArrayList<Integer> temp2 = new ArrayList<>();
        for(int i=0; i<mask.length; i++){
           if(mask[i]==0){
               for(int j=0; j<mask.length; j++){
                if (contains(childChromosome2,parentChromosome1.get(j))==false){
                    temp2.add(parentChromosome1.get(j));
                }
               }
           } 
        }
        int count2=0;
        for(int i=0; i<mask.length; i++){
           if(mask[i]==0){
               childChromosome2[i]=temp2.get(count2);
               count2++;
           } 
        }
       
        ArrayList<Integer> child1 = new ArrayList<>();
        ArrayList<Integer> child2 = new ArrayList<>();
        for(int i=0; i<childChromosome1.length;i++){
            child1.add(childChromosome1[i]);
            child2.add(childChromosome2[i]);
        }
        
        childChromosomes[0]=new Chromosome (child1);
        childChromosomes[1]=new Chromosome (child2);
        
        return childChromosomes;
    }
    
    public static boolean contains(int [] array, int item){
        for(int i : array){
            if(item==i){
                return true;
            }
        }
        return false;
    }
    //PMX crossover method
    public static Chromosome [] partiallyMappedCrossover (ArrayList<Integer> parentChromosome1, ArrayList<Integer> parentChromosome2){
        
        Chromosome [] childChromosomes = new Chromosome [2];       
        int [] mask = new int [parentChromosome1.size()];
        int[] childChromosome1 = new int [parentChromosome1.size()];
        int[] childChromosome2 = new int [parentChromosome2.size()];
        
                 
        Random r = new Random();
        int start = r.nextInt(parentChromosome1.size()-1);
        int end = r.nextInt(parentChromosome1.size()-1);
        
        while (start>end){
          start = r.nextInt(parentChromosome1.size()-1);
          end = r.nextInt(parentChromosome1.size()-1);
        }
                       
        int [] array1 = new int[end-start+1];
        int [] array2 = new int[end-start+1];
        
        
        int index=0;
        for (int i=0; i<childChromosome1.length; i++){
          if(i>=start && i<=end){ 
           childChromosome1[i] = parentChromosome2.get(i);
           childChromosome2[i] = parentChromosome1.get(i);
           array1[index]=childChromosome1[i];
           array2[index]=childChromosome2[i];
           index++;
           }
        }
        //**********************************************
        for(int i=0; i<childChromosome1.length; i++){
          if(i<start || i>end){
            if(contains(array1,parentChromosome1.get(i))==false){
                childChromosome1[i]=parentChromosome1.get(i);
            }
          }
        }
        ArrayList<Integer> temp = new ArrayList<>();
        for(int i=0; i<childChromosome1.length;i++){
            if (contains(childChromosome1,parentChromosome1.get(i))==false){
                temp.add(parentChromosome1.get(i));
            }
        }
        int position=0;
        for(int i=0; i<childChromosome1.length;i++){
            if(childChromosome1[i]==0){
                childChromosome1[i]=temp.get(position);
                position++;
            }
        }
      //**********************************  
        
        
        for(int i=0; i<childChromosome2.length; i++){
          if(i<start || i>end){
            if(contains(array2,parentChromosome2.get(i))==false){
                childChromosome2[i]=parentChromosome2.get(i);
            }
          }
        }
        ArrayList<Integer> temp1 = new ArrayList<>();
        for(int i=0; i<childChromosome2.length;i++){
            if (contains(childChromosome2,parentChromosome2.get(i))==false){
                temp1.add(parentChromosome2.get(i));
            }
        }
        int position1=0;
        for(int i=0; i<childChromosome2.length;i++){
            if(childChromosome2[i]==0){
                childChromosome2[i]=temp1.get(position1);
                position1++;
            }
        }
      //***********************************  
       
        
        ArrayList<Integer> child1 = new ArrayList<>();
        ArrayList<Integer> child2 = new ArrayList<>();
        for(int i=0; i<childChromosome1.length;i++){
            child1.add(childChromosome1[i]);
            child2.add(childChromosome2[i]);
        }
        
        childChromosomes[0]=new Chromosome (child1);
        childChromosomes[1]=new Chromosome (child2);
        
        return childChromosomes;
    }
    //Inverse mutation method
    public static Chromosome inverseMutation(ArrayList<Integer> oneChild){
        Chromosome chromosome;
        
        Random r = new Random();
        int start = r.nextInt(oneChild.size()-1);
        int end = r.nextInt(oneChild.size()-1);
        
        while (start>end){
          start = r.nextInt(oneChild.size()-1);
          end = r.nextInt(oneChild.size()-1);
        }
                       
        ArrayList<Integer> array = new ArrayList<>();
        
        for(int i=start; i<=end; i++){
            array.add(oneChild.get(i));
        }
        Collections.reverse(array);
        
        int index=0;
        for(int i=0; i<oneChild.size();i++){
            if(i>=start && i<=end){
                oneChild.set(i, array.get(index));
                index++;
            }
        }
        
        chromosome = new Chromosome(oneChild);
                      
        return chromosome;
    }
    
}
