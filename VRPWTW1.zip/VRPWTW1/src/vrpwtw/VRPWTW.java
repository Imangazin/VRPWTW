/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vrpwtw;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author ni15dz
 */
public class VRPWTW {

    static int i;
    
    
    public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException {
        
        File solomonData = new File("src/SolomonData/C105_200.csv");
        //File[] listOfFiles = solomonData.listFiles();
        
       /* for (File file: listOfFiles){
           Parameters.setParameters(file);
           
        }*/
       //Output file
       PrintWriter output = new PrintWriter("output.txt","UTF-8");
       output.println("VRPWTW - Weighted Sum Fitness");
       output.println("by Nurbek Imangazin");
       
       Parameters.setParameters(solomonData);//sets all user enterd parameters and Solomon Dataset
       
        for (int r=1; r<= Parameters.numberOfRuns; r++){//loop for number of runs
            output.println("******************************************************");
            System.out.println("**************************************************");
                    ArrayList<Chromosome> onePopulation = new ArrayList<>();  
                    ArrayList<Population> populations = new ArrayList<>();

                    populations.add(new Population()); //initial population
                    onePopulation = populations.get(0).nextPopulation;

                    for(i=0; i<Parameters.numberOfPopulation-1; i++){ // initial population
                       populations.add(new Population(onePopulation));
                       onePopulation = populations.get(populations.size()-1).nextPopulation;
                    }     

                    for (int j=0; j<Parameters.numberOfGenerations; j++){//loop for number of generations
                        output.println("Run number: "+r+";  Generation number: "+j);
                        System.out.println("Run number: "+r+";  Generation number: "+j);
                        output.print("Best Fitness for Generaion "+j+" = "+populations.get(j).nextPopulation.get(0).fitness);
                        output.println(populations.get(j).nextPopulation.get(0).fitness+" ");
                        output.println("Average Fitness for Generaion "+j+" = "+populations.get(j).averageFitness);
                        System.out.print("Best Fitness for Generaion "+j+" = "+populations.get(j).nextPopulation.get(0).fitness);
                        System.out.println("    Average Fitness for Generaion "+j+" = "+populations.get(j).averageFitness);
                        
                    } 
        }
        output.close();
        
     
    }
    
}
