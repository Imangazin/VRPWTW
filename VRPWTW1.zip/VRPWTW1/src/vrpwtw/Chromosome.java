/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vrpwtw;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

/**
 *
 * @author ni15dz
 * Chromosome representations
 */
public class Chromosome {
    ArrayList<Integer> chromosome = new ArrayList<>();//individuals
    ArrayList<Vehicle> vehicles = new ArrayList<>();//vehices
    int numberOfVehicles = 0;// number of vehicles per one chromosome
    double totalCost = 0;//total distance traveled by all vehicles 
    double fitness=0;//fitness value for chromosome
    int capacity = Parameters.capacity; //vehicle capacity
    int[] locationId = Parameters.getLocationId(); //holds sorted location Ids
    ArrayList<Locations> locations = Parameters.getLocations(); //
    public ArrayList<Integer> getChromosome () {return chromosome;}
    public ArrayList<Vehicle> getVehicles(){return vehicles;}
    
    public Chromosome (){     //initialisine chromosome
        
        for(int i=0; i<locations.size();i++){
            locations.get(i).flag=true;
        }
        
        for (int i=0; i<locationId.length; i++)
            chromosome.add(locationId[i]);   
        Collections.shuffle(chromosome);  
        
        devideChromosomesIntoVehicles(); 
        setWeightedSumFitness();
    }
    
    public void devideChromosomesIntoVehicles(){     //devides path into vehicles   
        ArrayList<Integer> tempChromosome = new ArrayList<>(chromosome);
        int count=0;        
        while (tempChromosome.size()>count){
            Vehicle newVehicle = new Vehicle();
            for(int i=0; i<tempChromosome.size();i++){           
                if (newVehicle.isVehicleCanServeNewLocation(locations.get(tempChromosome.get(i)))&&
                        locations.get(tempChromosome.get(i)).flag==true){
                    newVehicle.addNewLocation(locations.get(tempChromosome.get(i)));                                    
                    count++; 
                    locations.get(tempChromosome.get(i)).flag=false;
                }                
            }            
            vehicles.add(newVehicle);          
        }      
        for(int i=0; i<vehicles.size(); i++){
           totalCost = totalCost+vehicles.get(i).getTotalDistanceTraveled();          
        }        
        numberOfVehicles=vehicles.size();
    }
    
    public void setWeightedSumFitness (){ //fitness calculation
        fitness = 2*numberOfVehicles+3*totalCost;
    }
    public double getWeightedSumFitnessFitness (){
        return fitness;
    }
    
    public Chromosome(ArrayList<Integer> chromosome){//initialisine chromosome
        for(int i=0; i<locations.size();i++){
            locations.get(i).flag=true;
        }
        this.chromosome=chromosome;
        devideChromosomesIntoVehicles(); 
        setWeightedSumFitness();
    }
}
